export type Faction = 'aurora' | 'umbra' | 'neutral';
export type Keyword = 'guard' | 'rush' | 'shield' | 'lifesteal';
export type Effect = { kind:'damage'|'heal'|'draw'|'summon'|'buff'|'armor'; amount:number; target?:'enemyHero'|'ownHero'|'enemyAll'|'friendlyAll'; tokenId?:string };
export type CardDef = { id:string; name:string; cost:number; type:'unit'|'spell'; attack?:number; health?:number; faction:Faction; rarity:'comum'|'rara'|'épica'; tribe?:string; text:string; keywords?:Keyword[]; battlecry?:Effect; spell?:Effect; icon:string; flavor:string };
export const CARDS:CardDef[] = [
{id:'squire',name:'Escudeiro Solar',cost:1,type:'unit',attack:1,health:2,faction:'aurora',rarity:'comum',text:'Um defensor da primeira luz.',keywords:['guard'],icon:'☀',flavor:'A alvorada começa em silêncio.'},
{id:'sprite',name:'Fagulha Viva',cost:1,type:'unit',attack:2,health:1,faction:'neutral',rarity:'comum',text:'Uma centelha inquieta.',icon:'✦',flavor:'Brilha antes de desaparecer.'},
{id:'scout',name:'Batedora Lunar',cost:1,type:'unit',attack:1,health:1,faction:'umbra',rarity:'comum',text:'Ao entrar: compre 1 carta.',battlecry:{kind:'draw',amount:1},icon:'☾',flavor:'O escuro revela caminhos.'},
{id:'healer',name:'Curandeira do Vale',cost:2,type:'unit',attack:2,health:2,faction:'aurora',rarity:'comum',text:'Ao entrar: restaure 3 de vida ao seu herói.',battlecry:{kind:'heal',amount:3,target:'ownHero'},icon:'✚',flavor:'Ainda há tempo para florescer.'},
{id:'wolf',name:'Lobo Crepuscular',cost:2,type:'unit',attack:3,health:2,faction:'neutral',rarity:'comum',tribe:'Fera',text:'Um caçador incansável.',icon:'♞',flavor:'O uivo atravessa dois mundos.'},
{id:'sentinel',name:'Sentinela de Âmbar',cost:2,type:'unit',attack:1,health:4,faction:'aurora',rarity:'comum',text:'Guarda: inimigos devem atacar esta unidade primeiro.',keywords:['guard'],icon:'⬡',flavor:'Nenhuma sombra passa.'},
{id:'imp',name:'Diabrete Nebuloso',cost:2,type:'unit',attack:3,health:1,faction:'umbra',rarity:'comum',text:'Ímpeto: pode atacar unidades no turno em que entra.',keywords:['rush'],icon:'♠',flavor:'A névoa ri de volta.'},
{id:'archer',name:'Arqueira dos Ventos',cost:3,type:'unit',attack:3,health:3,faction:'neutral',rarity:'comum',text:'Ataque equilibrado.',icon:'➶',flavor:'Toda flecha escolhe seu destino.'},
{id:'paladin',name:'Guardião da Aurora',cost:3,type:'unit',attack:2,health:4,faction:'aurora',rarity:'rara',text:'Guarda e Escudo: bloqueia o primeiro dano.',keywords:['guard','shield'],icon:'♜',flavor:'Sua promessa nunca se apaga.'},
{id:'seer',name:'Oráculo da Névoa',cost:3,type:'unit',attack:2,health:3,faction:'umbra',rarity:'rara',text:'Ao entrar: compre 1 carta.',battlecry:{kind:'draw',amount:1},icon:'◈',flavor:'Enxerga o que não aconteceu.'},
{id:'raider',name:'Incursor das Dunas',cost:3,type:'unit',attack:4,health:2,faction:'neutral',rarity:'comum',text:'Ímpeto: pode atacar unidades imediatamente.',keywords:['rush'],icon:'⚔',flavor:'A areia cobre seus rastros.'},
{id:'priestess',name:'Sacerdotisa Estelar',cost:4,type:'unit',attack:3,health:5,faction:'aurora',rarity:'rara',text:'Ao entrar: ganhe 3 de armadura.',battlecry:{kind:'armor',amount:3,target:'ownHero'},icon:'✧',flavor:'Seu manto guarda constelações.'},
{id:'shade',name:'Espreitador Sombrio',cost:4,type:'unit',attack:5,health:3,faction:'umbra',rarity:'rara',text:'Roubo de vida: o dano causado cura seu herói.',keywords:['lifesteal'],icon:'☽',flavor:'Devolve apenas o que toma.'},
{id:'golem',name:'Golem de Obsidiana',cost:4,type:'unit',attack:3,health:6,faction:'neutral',rarity:'rara',text:'Guarda: protege seu herói.',keywords:['guard'],icon:'⬢',flavor:'Foi esculpido de uma noite antiga.'},
{id:'phoenix',name:'Fênix do Poente',cost:5,type:'unit',attack:5,health:4,faction:'aurora',rarity:'épica',text:'Escudo: bloqueia o primeiro dano.',keywords:['shield'],icon:'♨',flavor:'Renovada na última chama.'},
{id:'reaper',name:'Ceifador do Véu',cost:5,type:'unit',attack:6,health:4,faction:'umbra',rarity:'épica',text:'Ímpeto: pode atacar unidades imediatamente.',keywords:['rush'],icon:'⚚',flavor:'A fronteira entre mundos é tênue.'},
{id:'dragon',name:'Dragão do Eclipse',cost:7,type:'unit',attack:7,health:7,faction:'neutral',rarity:'épica',tribe:'Dragão',text:'Ao entrar: cause 2 de dano ao herói inimigo.',battlecry:{kind:'damage',amount:2,target:'enemyHero'},icon:'♛',flavor:'Um céu inteiro em suas asas.'},
{id:'titan',name:'Titã Celeste',cost:8,type:'unit',attack:8,health:9,faction:'aurora',rarity:'épica',text:'Guarda.',keywords:['guard'],icon:'✵',flavor:'As montanhas se curvam.'},
{id:'bolt',name:'Raio Primordial',cost:1,type:'spell',faction:'neutral',rarity:'comum',text:'Cause 2 de dano ao herói inimigo.',spell:{kind:'damage',amount:2,target:'enemyHero'},icon:'ϟ',flavor:'Rasgou o céu por um instante.'},
{id:'mend',name:'Luz Restauradora',cost:1,type:'spell',faction:'aurora',rarity:'comum',text:'Restaure 4 de vida ao seu herói.',spell:{kind:'heal',amount:4,target:'ownHero'},icon:'✺',flavor:'Uma esperança basta.'},
{id:'insight',name:'Segredos Arcanos',cost:2,type:'spell',faction:'neutral',rarity:'comum',text:'Compre 2 cartas.',spell:{kind:'draw',amount:2},icon:'✎',flavor:'As palavras lembram.'},
{id:'blast',name:'Chama Negra',cost:2,type:'spell',faction:'umbra',rarity:'comum',text:'Cause 3 de dano ao herói inimigo.',spell:{kind:'damage',amount:3,target:'enemyHero'},icon:'♨',flavor:'Nem todo fogo ilumina.'},
{id:'ritual',name:'Ritual de Ferro',cost:2,type:'spell',faction:'aurora',rarity:'comum',text:'Ganhe 5 de armadura.',spell:{kind:'armor',amount:5,target:'ownHero'},icon:'⬟',flavor:'Votos feitos em metal.'},
{id:'reinforce',name:'Chamado da Guarda',cost:3,type:'spell',faction:'aurora',rarity:'rara',text:'Invoque um Escudeiro Solar.',spell:{kind:'summon',amount:1,tokenId:'squire'},icon:'⚑',flavor:'Ao chamado, respondem.'},
{id:'whispers',name:'Sussurros do Véu',cost:3,type:'spell',faction:'umbra',rarity:'rara',text:'Compre 2 cartas.',spell:{kind:'draw',amount:2},icon:'☷',flavor:'O conhecimento tem preço.'},
{id:'storm',name:'Tempestade Astral',cost:4,type:'spell',faction:'neutral',rarity:'rara',text:'Cause 2 de dano a todas as unidades inimigas.',spell:{kind:'damage',amount:2,target:'enemyAll'},icon:'☄',flavor:'O céu caiu em fragmentos.'},
{id:'blessing',name:'Bênção da Alvorada',cost:4,type:'spell',faction:'aurora',rarity:'rara',text:'Dê +2/+2 às suas unidades.',spell:{kind:'buff',amount:2,target:'friendlyAll'},icon:'✴',flavor:'O primeiro raio fortalece.'},
{id:'doom',name:'Praga Umbral',cost:5,type:'spell',faction:'umbra',rarity:'épica',text:'Cause 3 de dano a todas as unidades inimigas.',spell:{kind:'damage',amount:3,target:'enemyAll'},icon:'☠',flavor:'Silêncio, então a queda.'},
{id:'comet',name:'Cometa Rubro',cost:6,type:'spell',faction:'neutral',rarity:'épica',text:'Cause 7 de dano ao herói inimigo.',spell:{kind:'damage',amount:7,target:'enemyHero'},icon:'✷',flavor:'A última estrela a cair.'},
{id:'renewal',name:'Renascimento',cost:6,type:'spell',faction:'aurora',rarity:'épica',text:'Cure 8 de vida e ganhe 4 de armadura.',spell:{kind:'heal',amount:8,target:'ownHero'},battlecry:{kind:'armor',amount:4,target:'ownHero'},icon:'❀',flavor:'Toda aurora é uma segunda chance.'}
];
export const CARD_BY_ID = Object.fromEntries(CARDS.map(c=>[c.id,c])) as Record<string,CardDef>;
export const STARTER_IDS = ['squire','sprite','scout','healer','wolf','sentinel','imp','archer','paladin','seer','raider','priestess','shade','golem','phoenix','dragon','bolt','mend','insight','blast','ritual','reinforce','whispers','storm','blessing','doom','comet','renewal','reaper','titan'];
export const DEFAULT_DECK = STARTER_IDS;
