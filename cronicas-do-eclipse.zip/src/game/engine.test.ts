import { describe,it,expect } from 'vitest';
import { CARD_BY_ID, DEFAULT_DECK } from './cards';
import { apply,canAttack,legalActions,newGame,validDeck } from './engine';
const rng=()=>0.42;
describe('Motor de Crônicas do Eclipse',()=>{
 it('valida 30 cartas e cópias',()=>{expect(validDeck(DEFAULT_DECK)).toBe(true);expect(validDeck(DEFAULT_DECK.slice(1))).toBe(false);expect(validDeck(Array(30).fill('wolf'))).toBe(false);});
 it('inicia jogo com 30 de vida e 1 mana',()=>{const g=newGame(DEFAULT_DECK,DEFAULT_DECK,rng);expect(g.players[0].hp).toBe(30);expect(g.players[0].maxMana).toBe(1);expect(g.players[0].hand.length).toBe(4);expect(g.players[1].hand.length).toBe(4);});
 it('bloqueia jogada ilegal e fora do turno',()=>{const g=newGame(DEFAULT_DECK,DEFAULT_DECK,rng);expect(apply(g,1,{kind:'end'})).toBe(g);expect(apply(g,0,{kind:'play',index:999})).toBe(g);});
 it('alterna turnos e cresce mana',()=>{let g=newGame(DEFAULT_DECK,DEFAULT_DECK,rng);g=apply(g,0,{kind:'end'});expect(g.current).toBe(1);expect(g.players[1].mana).toBe(1);g=apply(g,1,{kind:'end'});expect(g.players[0].mana).toBe(2);});
 it('permite jogar carta acessível descontando mana',()=>{const g=newGame(DEFAULT_DECK,DEFAULT_DECK,rng);const move=legalActions(g,0).find(a=>a.kind==='play');if(!move||move.kind!=='play')return;const cardId=g.players[0].hand[move.index];const result=apply(g,0,move);expect(result.players[0].mana).toBe(1-CARD_BY_ID[cardId].cost);expect(result.players[0].hand.length).toBeLessThanOrEqual(g.players[0].hand.length);expect(cardId).toBeTruthy();expect(g.players[0].mana).toBe(1);});
 it('unidade recém-invocada não ataca herói',()=>{let g=newGame(DEFAULT_DECK,DEFAULT_DECK,rng);g.players[0].hand=['squire'];g=apply(g,0,{kind:'play',index:0});expect(g.players[0].field.length).toBe(1);expect(canAttack(g,0,g.players[0].field[0].uid,'hero')).toBe(false);});
 it('causa fadiga quando o baralho está vazio',()=>{let g=newGame(DEFAULT_DECK,DEFAULT_DECK,rng);g.players[1].deck=[];g=apply(g,0,{kind:'end'});expect(g.players[1].hp).toBe(29);expect(g.players[1].fatigue).toBe(1);});
});
