# Crônicas do Eclipse — MVP

Jogo de cartas original em React + TypeScript. Partida local contra IA determinística de heurísticas, sem conta, servidor ou APIs pagas.

## Instalar e executar

Requer Node.js 20.19+ ou 22.12+.

```bash
npm install
npm run dev
```

Abra a URL mostrada pelo Vite (geralmente http://localhost:5173).

Para gerar produção: `npm run build`. Testes: `npm test`.

## Controles

- Clique numa carta na mão para jogar, desde que possua mana.
- Clique numa criatura sua pronta, depois na criatura adversária ou no herói, para atacar.
- Clique em **Encerrar turno** para a IA agir.
- Crie seu baralho em **Baralho**. Salvo no armazenamento local do navegador.

## Regras do MVP

- 30 de vida, baralhos de exatamente 30 cartas, no máximo duas cópias por carta.
- Deck inicial de 30 cartas distintas; 30 cartas disponíveis na coleção.
- 3 cartas iniciais para o jogador, 4 para a IA; ambos compram 1 ao iniciar o turno, incluindo o primeiro turno.
- Mana começa em 1 e aumenta até 10, recuperando a cada turno.
- Até 7 unidades no campo e 10 cartas na mão; cartas compradas com mão cheia são queimadas.
- Unidades atacam uma vez por turno. Ímpeto permite atacar **unidades** imediatamente, não o herói.
- Guarda exige atacar as unidades com Guarda antes de outros alvos; Escudo absorve uma instância de dano; Roubo de vida cura o herói pelo dano efetivamente causado.
- Combate de criaturas tem dano simultâneo; dano ao herói é mitigado por armadura.
- Se o baralho acabar, compra causa 1, 2, 3... de dano por fadiga. Vida zero encerra a partida.
- O computador usa regras de prioridade: golpe final, trocas vantajosas, cartas de alto valor e dano direto.

## Limitações deliberadas

Sem multiplayer, classes exclusivas, mulligan, armas, targeting manual de feitiços, efeito de morte, áudio ou ilustrações próprias. Ícones tipográficos provisórios mantêm o jogo leve. Não foram copiadas artes ou personagens de outros jogos. A IA é heurística, não depende de IA generativa nem de APIs externas.

## Estrutura

`src/game/cards.ts`: 30 definições de cartas originais.
`src/game/engine.ts`: estado imutável por ação, regras, validação e adversário.
`src/App.tsx`: páginas, mesa, deckbuilder e interações.
`src/style.css`: aparência responsiva.
`src/game/engine.test.ts`: testes das regras.
